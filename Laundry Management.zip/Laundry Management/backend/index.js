const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser');
const mysql = require('mysql');


// Create a connection to the MySQL database
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '123456789',
    database: 'laundry',
});

connection.connect((error) => {
    if (error) {
        console.error('Error connecting to MySQL:', error);
    } else {
        console.log('Connected to MySQL database');
    }
});


// Create a new Express app
const app = express();
app.use(cors())

// Parse JSON-encoded bodies
app.use(bodyParser.json());

// SIgnUp API
app.post('/signup', (req, res) => {
    const { name, email, password } = req.body;

    // Check if a user with the same email already exists
    connection.query(
        'SELECT * FROM new_users WHERE email = ?',
        [email],
        (error, results) => {
            if (error) {
                console.error('Error querying MySQL:', error);
                res.status(500).send({ message: 'Internal server error' });
                return;
            }

            if (results.length > 0) {
                res.status(409).send({ message: 'Email already exists' });
                return;
            }

            // Create a new user
            connection.query(
                'INSERT INTO new_users (name, email, password) VALUES (?, ?, ?)',
                [name, email, password],
                (error) => {
                    if (error) {
                        console.error('Error querying MySQL:', error);
                        res.status(500).send({ message: 'Internal server error' });
                        return;
                    }

                    res.status(200).send({ message: 'User created successfully' });
                }
            );
        }
    );
});

//Signin API
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    // Find the user by email
    connection.query(
        'SELECT * FROM new_users WHERE email = ?',
        [email],
        (error, results) => {
            if (error) {
                console.error('Error querying MySQL:', error);
                res.status(500).send({ message: 'Internal server error' });
                return;
            }

            if (results.length === 0) {
                res.status(401).send({ message: 'Invalid email or password' });
                return;
            }

            const user = results[0];

            // Check if the password matches
            if (password !== user.password) {
                res.status(401).send({ message: 'Invalid email or password' });
                return;
            }

            // Passwords match, user is authenticated
            res.status(200).send({ message: 'User authenticated successfully' });
        }
    );
});

//HOME page API
app.get('/Home', (req, res) => {
    res.send('Welcome to homepage!');
  });

// Start the server
app.listen(4000, () => {
    console.log('Server listening on port 4000');
});
