document.querySelector('#signup-form').addEventListener('submit', function(event) {
    event.preventDefault();
  
    var name = document.querySelector('#signup-form input[name="name"]').value;
    var email = document.querySelector('#signup-form input[name="email"]').value;
    var password = document.querySelector('#signup-form input[name="password"]').value;

  
    fetch('http://localhost:4000/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name: name, email: email, password: password })
    })
    .then(response => {
      if (response.ok) {
        console.log(response);
        alert('You have been successfully registered! You Can LogIn Now.');
        window.location.replace('index.html'); 
      } else {
        alert('There is an error registering your account.');
      }
    })
    .catch(error => {
      console.error('Error:', error);
    });
  });
  