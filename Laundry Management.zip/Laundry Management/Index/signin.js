document.querySelector('#login-form').addEventListener('submit', function(event) {
    event.preventDefault();
  
    var email = document.querySelector('#login-form input[name="email"]').value;
    var password = document.querySelector('#login-form input[name="password"]').value;

  
    fetch('http://localhost:4000/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email: email, password: password })
    })
    .then(response => {
      if (response.ok) {
        console.log(response);
        alert('You have been successfully loggedin!');
        window.location.replace('Home.html'); // Redirect to home.html
      } else {
        alert('Incorrect emailId or Password');
      }
    })
    .catch(error => {
      console.error('Error:', error);
    });
  });
  